﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using NUnit.Framework;
using RestSharp;

namespace API.Store
{
    internal class StoreTest
    {
        string endpoint = "https://petstore.swagger.io/v2";
        string id = "88230701";
        public void Setup()
        {
            var client = new RestClient("");
            var request = new RestRequest();
            request.AlwaysMultipartFormData = true;
            request.AddParameter("id", "");
            request.AddParameter("petID", "");
            request.AddParameter("quantity", "");
            request.AddParameter("shipdate", "");
            request.AddParameter("status", "");
            request.AddParameter("complete", "");
            var response = client.Post(request);
            var obj = JsonConvert.DeserializeObject<dynamic>(response.Content);
            Console.WriteLine(response.Content);
        }



        [Test]
        public void AddStore()
        {
            var client = new RestClient(endpoint+ "/store/order");
            var request = new RestRequest();
            request.AddHeader("Content-Type", "application/json");
            var body = "";
            request.AddParameter("application/json", body, ParameterType.RequestBody);
            var response = client.Post(request);
            var obj = JsonConvert.DeserializeObject<dynamic>(response.Content);
            Console.WriteLine(response.Content);
            Console.WriteLine(response.StatusCode);
            GetStoreID();
        }

        [Test]
        public void GetStoreID()
        {
            var client = new RestClient(endpoint+ "/store/order/"+id);
            var request = new RestRequest();
            var storeid = "";
            request.AddParameter("application/json", storeid, ParameterType.RequestBody);
            var response = client.Get(request);
            Console.WriteLine(response.Content);
            Console.WriteLine(response.StatusCode);
        }
    }
}
