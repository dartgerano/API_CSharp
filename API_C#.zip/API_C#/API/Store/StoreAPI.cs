﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using NUnit.Framework;
using RestSharp;

namespace API.Store
{
    public class StoreAPI
    {
        string endpoint = "https://petstore.swagger.io/v2";
        string token = "";
        string id = "88230701";

        [Test]
        public void AddStore()
        {
            var client = new RestClient(endpoint + "/store/order");
            var request = new RestRequest();
            request.AddHeader("Content-Type", "application/json");
            var body =@"{
                " + "\n" +
                @"  ""id"": 0, " + "\n" +
                @"  ""petId"": 0, " + "\n" +
                @"  ""quantity"": 20, " + "\n" +
                @"  ""shipdate"": 2022-09-15T14:39:15.464Z, " + "\n" +
                @"  ""status"": placed, " + "\n" +
                @"  ""complete"": true, " + "\n" +
                @"}";
            request.AddParameter("application/json", body, ParameterType.RequestBody);
            var response = client.Post(request);
            GetStoreID();
        }

        [Test]
        public void GetStoreID()
        {
            var client = new RestClient(endpoint + "/store/order/"+id);
            var request = new RestRequest();
            var response = client.Get(request);
            Console.WriteLine(response.Content);
        }

        [Test]
        public void DeleteStore()
        {
            var client = new RestClient(endpoint + "/store/order/88230702");
            var request = new RestRequest();
            request.AddHeader("Authorization", "Bearer " + token);
            var response = client.Post(request);
            Console.WriteLine(response.Content);
            GetStoreID();
            Console.WriteLine(response.StatusCode);
        }
    }
}
